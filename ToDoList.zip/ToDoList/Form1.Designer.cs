﻿namespace ToDoList
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.txtBox = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.lstBox = new System.Windows.Forms.ListBox();
            this.btnRm = new System.Windows.Forms.Button();
            this.btnSettings = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.lblBg = new System.Windows.Forms.Label();
            this.pnl = new System.Windows.Forms.Panel();
            this.cbtnBlue = new ToDoList.circleButton();
            this.cbtnTeal = new ToDoList.circleButton();
            this.cbtnPink = new ToDoList.circleButton();
            this.cbtnViolet = new ToDoList.circleButton();
            this.cbtnOrange = new ToDoList.circleButton();
            this.pnl.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtBox
            // 
            this.txtBox.BackColor = System.Drawing.Color.White;
            this.txtBox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBox.ForeColor = System.Drawing.Color.Gainsboro;
            this.txtBox.Location = new System.Drawing.Point(63, 346);
            this.txtBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.txtBox.Multiline = true;
            this.txtBox.Name = "txtBox";
            this.txtBox.Size = new System.Drawing.Size(379, 39);
            this.txtBox.TabIndex = 2;
            this.txtBox.Text = "Type something...";
            this.txtBox.TextChanged += new System.EventHandler(this.txtBox_TextChanged);
            this.txtBox.Enter += new System.EventHandler(this.txtBox_Enter);
            this.txtBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtBox_KeyDown);
            this.txtBox.Leave += new System.EventHandler(this.txtBox_Leave);
            // 
            // btnSave
            // 
            this.btnSave.BackColor = System.Drawing.Color.White;
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(54)))));
            this.btnSave.Location = new System.Drawing.Point(514, 170);
            this.btnSave.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 40);
            this.btnSave.TabIndex = 4;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            this.btnSave.MouseEnter += new System.EventHandler(this.btnSave_MouseEnter);
            this.btnSave.MouseLeave += new System.EventHandler(this.btnSave_MouseLeave);
            // 
            // lstBox
            // 
            this.lstBox.BackColor = System.Drawing.Color.White;
            this.lstBox.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstBox.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(54)))));
            this.lstBox.FormattingEnabled = true;
            this.lstBox.ItemHeight = 30;
            this.lstBox.Location = new System.Drawing.Point(34, 32);
            this.lstBox.Name = "lstBox";
            this.lstBox.Size = new System.Drawing.Size(462, 274);
            this.lstBox.TabIndex = 5;
            // 
            // btnRm
            // 
            this.btnRm.BackColor = System.Drawing.Color.White;
            this.btnRm.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRm.Font = new System.Drawing.Font("Segoe UI Emoji", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRm.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(54)))));
            this.btnRm.Location = new System.Drawing.Point(514, 110);
            this.btnRm.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnRm.Name = "btnRm";
            this.btnRm.Size = new System.Drawing.Size(100, 40);
            this.btnRm.TabIndex = 6;
            this.btnRm.Text = "Remove";
            this.btnRm.UseVisualStyleBackColor = false;
            this.btnRm.Click += new System.EventHandler(this.btnRm_Click);
            this.btnRm.MouseEnter += new System.EventHandler(this.btnRm_MouseEnter);
            this.btnRm.MouseLeave += new System.EventHandler(this.btnRm_MouseLeave);
            // 
            // btnSettings
            // 
            this.btnSettings.BackColor = System.Drawing.Color.White;
            this.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSettings.Font = new System.Drawing.Font("Segoe UI Emoji", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSettings.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(54)))));
            this.btnSettings.Location = new System.Drawing.Point(514, 50);
            this.btnSettings.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(100, 40);
            this.btnSettings.TabIndex = 7;
            this.btnSettings.Text = "Settings";
            this.btnSettings.UseVisualStyleBackColor = false;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            this.btnSettings.MouseEnter += new System.EventHandler(this.btnSettings_Enter);
            this.btnSettings.MouseLeave += new System.EventHandler(this.btnSettings_Leave);
            // 
            // btnBack
            // 
            this.btnBack.BackColor = System.Drawing.Color.White;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBack.Font = new System.Drawing.Font("Segoe UI Emoji", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(54)))));
            this.btnBack.Location = new System.Drawing.Point(514, 110);
            this.btnBack.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(100, 40);
            this.btnBack.TabIndex = 8;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = false;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            this.btnBack.MouseEnter += new System.EventHandler(this.btnBack_Enter);
            this.btnBack.MouseLeave += new System.EventHandler(this.btnBack_Leave);
            // 
            // lblBg
            // 
            this.lblBg.AutoSize = true;
            this.lblBg.BackColor = System.Drawing.Color.Transparent;
            this.lblBg.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBg.ForeColor = System.Drawing.Color.White;
            this.lblBg.Location = new System.Drawing.Point(30, 32);
            this.lblBg.Name = "lblBg";
            this.lblBg.Size = new System.Drawing.Size(96, 21);
            this.lblBg.TabIndex = 9;
            this.lblBg.Text = "Background:";
            this.lblBg.Click += new System.EventHandler(this.label1_Click);
            // 
            // pnl
            // 
            this.pnl.BackColor = System.Drawing.Color.White;
            this.pnl.Controls.Add(this.cbtnBlue);
            this.pnl.Controls.Add(this.cbtnTeal);
            this.pnl.Controls.Add(this.cbtnPink);
            this.pnl.Controls.Add(this.cbtnViolet);
            this.pnl.Controls.Add(this.cbtnOrange);
            this.pnl.ForeColor = System.Drawing.Color.White;
            this.pnl.Location = new System.Drawing.Point(63, 67);
            this.pnl.Name = "pnl";
            this.pnl.Size = new System.Drawing.Size(399, 100);
            this.pnl.TabIndex = 12;
            // 
            // cbtnBlue
            // 
            this.cbtnBlue.BackColor = System.Drawing.Color.SkyBlue;
            this.cbtnBlue.FlatAppearance.BorderSize = 0;
            this.cbtnBlue.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbtnBlue.Location = new System.Drawing.Point(320, 24);
            this.cbtnBlue.Name = "cbtnBlue";
            this.cbtnBlue.Size = new System.Drawing.Size(50, 50);
            this.cbtnBlue.TabIndex = 14;
            this.cbtnBlue.UseVisualStyleBackColor = false;
            this.cbtnBlue.Click += new System.EventHandler(this.cbtnBlue_Click);
            // 
            // cbtnTeal
            // 
            this.cbtnTeal.BackColor = System.Drawing.Color.Teal;
            this.cbtnTeal.FlatAppearance.BorderSize = 0;
            this.cbtnTeal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbtnTeal.Location = new System.Drawing.Point(248, 24);
            this.cbtnTeal.Name = "cbtnTeal";
            this.cbtnTeal.Size = new System.Drawing.Size(50, 50);
            this.cbtnTeal.TabIndex = 13;
            this.cbtnTeal.UseVisualStyleBackColor = false;
            this.cbtnTeal.Click += new System.EventHandler(this.cbtnTeal_Click);
            // 
            // cbtnPink
            // 
            this.cbtnPink.BackColor = System.Drawing.Color.Crimson;
            this.cbtnPink.FlatAppearance.BorderSize = 0;
            this.cbtnPink.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbtnPink.Location = new System.Drawing.Point(174, 24);
            this.cbtnPink.Name = "cbtnPink";
            this.cbtnPink.Size = new System.Drawing.Size(50, 50);
            this.cbtnPink.TabIndex = 12;
            this.cbtnPink.UseVisualStyleBackColor = false;
            this.cbtnPink.Click += new System.EventHandler(this.cbtnPink_Click);
            // 
            // cbtnViolet
            // 
            this.cbtnViolet.BackColor = System.Drawing.Color.DarkMagenta;
            this.cbtnViolet.FlatAppearance.BorderSize = 0;
            this.cbtnViolet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbtnViolet.Location = new System.Drawing.Point(27, 24);
            this.cbtnViolet.Name = "cbtnViolet";
            this.cbtnViolet.Size = new System.Drawing.Size(50, 50);
            this.cbtnViolet.TabIndex = 10;
            this.cbtnViolet.UseVisualStyleBackColor = false;
            this.cbtnViolet.Click += new System.EventHandler(this.cbtnViolet_Click);
            // 
            // cbtnOrange
            // 
            this.cbtnOrange.BackColor = System.Drawing.Color.DarkOrange;
            this.cbtnOrange.FlatAppearance.BorderSize = 0;
            this.cbtnOrange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbtnOrange.Location = new System.Drawing.Point(101, 24);
            this.cbtnOrange.Name = "cbtnOrange";
            this.cbtnOrange.Size = new System.Drawing.Size(50, 50);
            this.cbtnOrange.TabIndex = 11;
            this.cbtnOrange.UseVisualStyleBackColor = false;
            this.cbtnOrange.Click += new System.EventHandler(this.cbtnOrange_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(634, 450);
            this.Controls.Add(this.pnl);
            this.Controls.Add(this.lblBg);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.btnRm);
            this.Controls.Add(this.lstBox);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.txtBox);
            this.Font = new System.Drawing.Font("Segoe UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.Coral;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "Form1";
            this.Text = "ToDoList";
            this.pnl.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtBox;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.ListBox lstBox;
        private System.Windows.Forms.Button btnRm;
        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Label lblBg;
        private circleButton cbtnViolet;
        private circleButton cbtnOrange;
        private System.Windows.Forms.Panel pnl;
        private circleButton cbtnPink;
        private circleButton cbtnTeal;
        private circleButton cbtnBlue;
    }
}

