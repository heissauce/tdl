﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ToDoList
{
    public partial class Form1 : Form
    {
        Color Greysh = Color.FromArgb(54, 54, 54);
        Color primaryColor = System.Drawing.Color.Teal;
        string sPath = "dbTDL.txt";

        public Form1()
        {
            InitializeComponent();
            btnBack.Visible = false;
            lblBg.Visible = false;
            cbtnViolet.Visible = false;
            cbtnOrange.Visible = false;
            pnl.Visible = false;
            if (File.Exists(sPath))
            {
                using (StreamReader r = new StreamReader(sPath))
                {
                    string line;
                    while ((line = r.ReadLine()) != null)
                    {
                        lstBox.Items.Add(line);
                    }
                }
            }                                    
        }

        private void txtBox_TextChanged(object sender, EventArgs e)
        {
            
        }
        
        private void txtBox_Enter(object sender, EventArgs e)
        {
            if(txtBox.Text == "Type something...")
            {
                txtBox.Text = "";
                txtBox.ForeColor = Greysh;
            }
        }        

        private void txtBox_Leave(object sender, EventArgs e)
        {
            if (txtBox.Text != "Type something..." && txtBox.Text == "") 
            {
                txtBox.Text = "Type something...";
                txtBox.ForeColor = System.Drawing.Color.Gainsboro;
                
            }            
        }
        
        private void txtBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                if (txtBox.Text != "")
                {
                    txtBox.Text = "\u2022 " + txtBox.Text;
                    lstBox.Items.Add(this.txtBox.Text);
                    this.txtBox.Clear();
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            System.IO.StreamWriter SaveFile = new System.IO.StreamWriter(sPath);
            foreach (var item in lstBox.Items)
            {
                SaveFile.WriteLine(item.ToString());               
            }
            SaveFile.Close();
            MessageBox.Show("Saved!");
        }
        private void btnSave_MouseEnter(object sender, EventArgs e)
        {
            btnSave.BackColor = primaryColor;
            btnSave.ForeColor = System.Drawing.Color.White;
        }

        private void btnSave_MouseLeave(object sender, EventArgs e)
        {
            btnSave.BackColor = System.Drawing.Color.White;
            btnSave.ForeColor = Greysh;
        }

        private void btnRm_Click(object sender, EventArgs e)
        {
            if (this.lstBox.SelectedIndex >= 0)
            {
                this.lstBox.Items.RemoveAt(this.lstBox.SelectedIndex);
            }
        }

        private void btnRm_MouseEnter(object sender, EventArgs e)
        {
            btnRm.BackColor = primaryColor;
            btnRm.ForeColor = System.Drawing.Color.White; 
        }

        private void btnRm_MouseLeave(object sender, EventArgs e)
        {
            btnRm.BackColor = System.Drawing.Color.White;
            btnRm.ForeColor = Greysh;
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            btnRm.Visible = false;
            btnSave.Visible = false;
            btnBack.Visible = true;
            lstBox.Visible = false;
            txtBox.Visible = false;
            lblBg.Visible = true;
            cbtnViolet.Visible = true;
            cbtnOrange.Visible = true;
            pnl.Visible = true;
        }

        private void btnSettings_Enter(object sender, EventArgs e)
        {
            btnSettings.BackColor = primaryColor;
            btnSettings.ForeColor = System.Drawing.Color.White;
        }

        private void btnSettings_Leave(object sender, EventArgs e)
        {
            btnSettings.BackColor = System.Drawing.Color.White;
            btnSettings.ForeColor = Greysh;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            btnRm.Visible = true;
            btnSave.Visible = true;
            btnBack.Visible = false;
            lstBox.Visible = true;
            txtBox.Visible = true;
            lblBg.Visible = false;
            cbtnViolet.Visible = false;
            cbtnOrange.Visible = false;
            pnl.Visible = false;
        }

        private void btnBack_Enter(object sender, EventArgs e)
        {
            btnBack.BackColor = primaryColor;
            btnBack.ForeColor = System.Drawing.Color.White;
        }

        private void btnBack_Leave(object sender, EventArgs e)
        {
            btnBack.BackColor = System.Drawing.Color.White;
            btnBack.ForeColor = Greysh;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void cbtnViolet_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.DarkMagenta;
            primaryColor = System.Drawing.Color.DarkMagenta;
        }

        private void cbtnOrange_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.DarkOrange;
            primaryColor = System.Drawing.Color.DarkOrange;
        }

        private void cbtnPink_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.Crimson;
            primaryColor = System.Drawing.Color.Crimson;
        }

        private void cbtnTeal_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.Teal;
            primaryColor = System.Drawing.Color.Teal;
        }

        private void cbtnBlue_Click(object sender, EventArgs e)
        {
            this.BackColor = System.Drawing.Color.SkyBlue;
            primaryColor = System.Drawing.Color.SkyBlue;
        }
    }   
}
