﻿namespace ToDoList
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblBg = new System.Windows.Forms.Label();
            this.cbtnTeal = new ToDoList.circleButton();
            this.cbtnOrange = new ToDoList.circleButton();
            this.cbtnPink = new ToDoList.circleButton();
            this.cbtnViolet = new ToDoList.circleButton();
            this.SuspendLayout();
            // 
            // lblBg
            // 
            this.lblBg.AutoSize = true;
            this.lblBg.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBg.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(54)))), ((int)(((byte)(54)))), ((int)(((byte)(54)))));
            this.lblBg.Location = new System.Drawing.Point(13, 13);
            this.lblBg.Name = "lblBg";
            this.lblBg.Size = new System.Drawing.Size(96, 21);
            this.lblBg.TabIndex = 0;
            this.lblBg.Text = "Background:";
            // 
            // cbtnTeal
            // 
            this.cbtnTeal.BackColor = System.Drawing.Color.Teal;
            this.cbtnTeal.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbtnTeal.Location = new System.Drawing.Point(34, 50);
            this.cbtnTeal.Name = "cbtnTeal";
            this.cbtnTeal.Size = new System.Drawing.Size(50, 50);
            this.cbtnTeal.TabIndex = 1;
            this.cbtnTeal.UseVisualStyleBackColor = false;
            this.cbtnTeal.Click += new System.EventHandler(this.cbtnTeal_Click);
            // 
            // cbtnOrange
            // 
            this.cbtnOrange.BackColor = System.Drawing.Color.DarkOrange;
            this.cbtnOrange.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbtnOrange.Location = new System.Drawing.Point(170, 50);
            this.cbtnOrange.Name = "cbtnOrange";
            this.cbtnOrange.Size = new System.Drawing.Size(50, 50);
            this.cbtnOrange.TabIndex = 2;
            this.cbtnOrange.UseVisualStyleBackColor = false;
            this.cbtnOrange.Click += new System.EventHandler(this.cbtnOrange_Click);
            // 
            // cbtnPink
            // 
            this.cbtnPink.BackColor = System.Drawing.Color.Crimson;
            this.cbtnPink.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbtnPink.Location = new System.Drawing.Point(237, 50);
            this.cbtnPink.Name = "cbtnPink";
            this.cbtnPink.Size = new System.Drawing.Size(50, 50);
            this.cbtnPink.TabIndex = 3;
            this.cbtnPink.UseVisualStyleBackColor = false;
            this.cbtnPink.Click += new System.EventHandler(this.cbtnPink_Click);
            // 
            // cbtnViolet
            // 
            this.cbtnViolet.BackColor = System.Drawing.Color.MediumVioletRed;
            this.cbtnViolet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.cbtnViolet.Location = new System.Drawing.Point(102, 50);
            this.cbtnViolet.Name = "cbtnViolet";
            this.cbtnViolet.Size = new System.Drawing.Size(50, 50);
            this.cbtnViolet.TabIndex = 4;
            this.cbtnViolet.UseVisualStyleBackColor = false;
            this.cbtnViolet.Click += new System.EventHandler(this.cbtnViolet_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(319, 257);
            this.Controls.Add(this.cbtnViolet);
            this.Controls.Add(this.cbtnPink);
            this.Controls.Add(this.cbtnOrange);
            this.Controls.Add(this.cbtnTeal);
            this.Controls.Add(this.lblBg);
            this.Name = "Form2";
            this.Text = "Form2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblBg;
        private circleButton cbtnTeal;
        private circleButton cbtnOrange;
        private circleButton cbtnPink;
        private circleButton cbtnViolet;
    }
}